<?php

# Saved in ISO-8859-1

$Finnish = array("���","���","ABCDEFGHIJKLMNOPQRSTUVXYZ","ISO-8859-1");

# Allowed characters

$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

# Add unique alphabet to standard alphabet, also add unqiue letters

$chars .= $Finnish[2].$Finnish[0].$Finnish[0];

?>
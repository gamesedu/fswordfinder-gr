<?php

# Saved in ISO-8859-1

$Danish = array("���","���","ABCDEFGHIJKLMNOPQRSTUVWXYZ","ISO-8859-1");

# Allowed characters

$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

# Add unique alphabet to standard alphabet, also add unqiue letters

$chars .= $Danish[2].$Danish[0].$Danish[0];

?>
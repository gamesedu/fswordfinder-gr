<?php

# Saved in ISO-8859-1

$Albanian = array("���","���","ABCDEFGHIJKLMNOPQRSTUVXYZ","ISO-8859-1");

# Allowed characters

$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

# Add unique alphabet to standard alphabet, also add unqiue letters

$chars .= $Albanian[2].$Albanian[0].$Albanian[0];

?>
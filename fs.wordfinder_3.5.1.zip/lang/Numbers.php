<?php

# Saved in ISO-8859-1

$Numbers = "1234567890";
$chars = $Numbers;

$d=0;
?>
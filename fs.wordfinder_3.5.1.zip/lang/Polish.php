<?php

# Saved in ISO-8859-2

# Translation table

$Polish_trans = array(
"&#260;"=>"�","&#261;"=>"�",
"&#262;"=>"�","&#263;"=>"�",
"&#280;"=>"�","&#281;"=>"�",
"&#321;"=>"�","&#322;"=>"�",
"&#323;"=>"�","&#324;"=>"�",
"&#346;"=>"�","&#347;"=>"�",
"&#377;"=>"�","&#378;"=>"�",
"&#379;"=>"�","&#380;"=>"�",
);

$tempWords = strtr($tempWords,$Polish_trans);

$Polish = array("��ʣ�Ӧ��","����󶼿","ABCDEFGHIJKLMNOPRSTUWYZ","ISO-8859-2");

# Allowed characters

$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

# Add unique alphabet to standard alphabet, also add unqiue letters

$chars .= $Polish[2].$Polish[0].$Polish[0];

?>
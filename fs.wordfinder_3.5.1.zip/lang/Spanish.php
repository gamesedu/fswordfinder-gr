<?php

# Saved in ISO-8859-1

$Spanish = array("�","�","ABCDEFGHIJKLMNOPQRSTUVWXYZ","ISO-8859-1");

# Allowed characters

$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

# Add unique alphabet to standard alphabet, also add unqiue letters

$chars .= $Spanish[2].$Spanish[0].$Spanish[0];

?>
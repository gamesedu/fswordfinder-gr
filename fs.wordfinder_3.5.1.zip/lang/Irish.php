<?php

# Saved in ISO-8859-1

$Irish = array("�����","�����","ABCDEFGHILMNOPRSTU","ISO-8859-1");

# Allowed characters

$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

# Add unique alphabet to standard alphabet, also add unqiue letters

$chars .= $Irish[2].$Irish[0].$Irish[0];

?>
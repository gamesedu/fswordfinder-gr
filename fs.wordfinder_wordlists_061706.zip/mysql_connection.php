<?php

$host = "localhost";
$database = "database";
$username = "username";
$password = "password";

?>
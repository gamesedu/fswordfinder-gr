<?php

$filename = "english_roman_deities.txt";

$set = "English_Roman_Deities";
$data = "English_Roman_Deities";
$random = 0;

@require("./mysql_connection.php");

###########################################################

$link = mysql_connect($host,$username,$password);
mysql_select_db($database);

if(!isset($_GET['seek'])) {
  $sql = "SHOW TABLES FROM fswordfinder LIKE 'FSWF_config'";
  $res = mysql_query($sql);
  if(!(mysql_num_rows($res))) {
    mysql_query("CREATE TABLE FSWF_config (fsset VARCHAR(50) NOT NULL, fsdata VARCHAR(50) NOT NULL, random TINYINT(1) NOT NULL, count MEDIUMINT(7) NOT NULL, PRIMARY KEY (fsset))");
  }
  if($random) {
    $t = strlen($data);
    for($a=0;$a<$t;$a++) {
      mysql_query("CREATE TABLE FSWF_".$set."_".$data[$a]." (word VARCHAR(50) NOT NULL, PRIMARY KEY (word))");
    }
  } else {
    mysql_query("CREATE TABLE FSWF_".$set." (word VARCHAR(50) NOT NULL, PRIMARY KEY (word))");
  }
}

$handle = fopen("./".$filename,"r");

if($_GET['seek']) $seek=$_GET['seek']; else $seek=0;
if($seek) { fseek($handle,$seek); }

$end=FALSE;

$count = (!empty($_GET['count'])) ? $_GET['count'] : 0;
for($a=0;$a<50000;$a++) {
  if(feof($handle)) { $end=TRUE; break; }
  $line = strtoupper(fgets($handle,50));
  $seek+=strlen($line);
  if($random) { mysql_query("INSERT INTO FSWF_".$set."_".substr($line,0,1)." VALUES ('".ereg_replace("[]!@#$%^&*()_=+[\;',./{}|:\"<>? -]*","",trim($line))."')"); if(mysql_affected_rows()>0) $count++; }
  else { mysql_query("INSERT INTO FSWF_".$set." VALUES ('".ereg_replace("[]!@#$%^&*()_=+[\;',./{}|:\"<>? -]*","",trim($line))."')"); if(mysql_affected_rows()>0) $count++; }
}
fclose($handle);

if(!$end) { $loc="http://".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?count=".$count."&seek=".$seek; header("Location:".$loc); exit; }

if($end) { mysql_query("INSERT INTO FSWF_config VALUES ('".$set."','".$data."','".$random."','".$count."')"); echo "Installed the word list: ".$set; }

mysql_close($link);

?>
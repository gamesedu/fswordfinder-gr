FS.WordFinder Word list addon (MySQL option)
============================================

This addon uses a MySQL database.  You must have access to MySQL to
use this addon.  Also, you will need to create the database before
using any word list install.  After you've done that, follow these
instructions:

1) Open mysql_connection.php with any text editor.  Edit the database
   connection values.  Upload this file to your server.  It must be
   in the same directory as the fs.wordfinder.php file.

2) Open fs.wordfinder.php with any text editor.  Go down to the word
   list addon options and change $wordlist to equal 1.  Now upload
   this file to your server.

3) Upload any *install.php and the corresponding .txt file to your
   server and into the same directory, and in the same directory as
   fs.wordfinder.php.  Launch the .php file in your browser and it
   will install that word list.  Do the same for any other word list
   you wish to install.  Some word lists are quite big and might take
   1-2 minutes, or longer depending on your server.

4) Delete all *install.php and corresponding .txt files.


FS.WordFinder Word list addon (non-MySQL option)
================================================

If you wish to use word lists without the use of a database, follow
these steps:

1) Open fs.wordfinder.php in a text editor and find the line:

   $wordlist = 0;

   and change this to equal 1. Close fs.wordfinder.php

2) Go onto your server and create a directory and name it wordlists.
   This directory needs to be in the same directory as
   fs.wordfinder.php. If you wish to move the directory to a
   different location on your server or give it a different name,
   then you'll need to edit fs.wordfinder.php to point to the new
   location and/or name.

3) After creating the wordlists directory, upload any word list you
   want to use into this directory. All you're uploading are the
   .txt files and not the .php files. Also, be very careful not to
   upload a file that's too big for your server to handle. Flat files
   are not as efficient as database files. As a general rule, do not
   upload any word list that's bigger than 100KB. You can always
   experiment with this limit on your own server.


Making your own word list
=========================

Making your own word list is pretty easy.  Just follow these
instructions:

1) Make a text file with each word on it's own seperate line.
   Duplicate words are not inserted into the database.  Non-alpha
   characters are removed. The name rules for the filename are:
   a) No 2 periods in sequence (eg, examp..le.txt)
   b) No @ # % & | " ' characters
   c) No longer than 100 characters

2) Open any *install.php file in any text editor and save it under a
   different name.

3) Change $filename to point to your word list file.

4) Change $set to what your word list will be named in the database
   and in the options dropdown on the main FS.WordFinder page.  Do
   not use spaces, use the underscore (_) instead.  In the dropdown
   menu, underscores are changed to spaces automatically.

5) Change $data.  This gets a little tricky.  If your word list is
   some where around 1MB, make $data equal to $set.  If it's larger
   than 1MB, you will have to enter that languages alphabet.  For
   example, the english word list is over 3MB so I had to enter in
   the english alphabet.  This will seperate the word list into
   seperate tables in the database for much quicker retrieval.

6) Change $random.  This is based on what your entered for $data.  If
   you entered $set as $data, $random is 0.  If you entered an
   alphabet, $random is 1.

7) Email me the word list and install file if you wish it to be
   included with the official addon in future releases.

Take a look at the differences between english_baseball_install.php
and english_install.php for help.